// Code goes here



//Check Off Specific Todos By Clicking

$("ul").on("click", "li", function(){
  console.log("clicked");
    
    $(this).toggleClass("completed");
    
});


//Click on the X to delete the Todo

$("ul").on("click", "span", function(event){
  console.log("clicked");
    $(this).parent().fadeOut(500, function(){  
        $(this).remove();             
    });
    //$(this).parent().remove();
    event.stopPropagation();
});



//add a listener to the text input that listens for the enter key
$("input[type='text']").on("keypress", function(event){
  console.log("clicked");
    
    console.log("keypress");
   
    if(event.which === 13){   
        //grab new todo text from the input
        var todoText = $(this).val();
        //clear the input screen after the user presses enter
        $(this).val("");
        //create a new li and add it to the ul
        $("ul").append("<li><span><i class = 'fa fa-trash'></i></span> " + todoText + "</li>");
    }
    else{}
});



//have the plus sign button fade in/out the 'Add New Todo' text input

$(".fa-plus").on("click", function(){
  console.log("clicked");
    
    $("input[type='text']").fadeToggle();
    
});



